<div class="header">
	
	<div class="header-text">
		<h2>Aamir Husain Ansari</h2>
	</div>
	
	<div class="header-logo">
		<a href="home.php" target="_self"><img src="images/new_logo.png" alt="logo"></a>
	</div>
	
	<div class="social-icons">
			<div class="icons-container">
			<a href="https://www.facebook.com/muhandis.aamir" target="_blank" class="fa fa-facebook"></a>
			</div>

			<div class="icons-container">
			<a href="https://github.com/enggaamir45" target="_blank" class="fa fa-github"></a>
			</div>

			<div class="icons-container">
			<a href="https://www.instagram.com/ar.ansari45/" target="_blank" class="fa fa-instagram"></a>
			</div>

			<div class="icons-container">
			<a href="https://www.linkedin.com/in/aamir-ansari-a1aa608a/" target="_blank" class="fa fa-linkedin"></a>
			</div>	
		</div>
</div>

<div class="menu">
	<label for="toggle">&#9776</label>
	<input type="checkbox" id="toggle">
	<div class="menu-wrapper">
	
		<ul class="clearfix">
		<li><a href="home.php" class="home">Home</a></li>
		<li><a href="about.php" class="about">About</a></li>
		<li><a href="portfolio.php" class="portfolio">Portfolio</a></li>
		<li><a href="resume.php" class="resume">Resume</a></li>
		<li><a href="contact.php" class="contact">Contact</a></li>
	    </ul>
	</div>
	
	
</div>