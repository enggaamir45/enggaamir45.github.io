<div class="confirmation">

	<div class="confirmation-message">
		
		<p class="check-mark">&#10003; </p>
		<h1>Your message has been sent.</h1>
		<h1> Thank You for contacting me. I will get back to you ASAP. </h1>

	</div>



</div>