<div class="portfolio_content">
	
	<div class="profile-heading3">
		<h1>Portfolio</h1>
	</div>
	
	<div class="portfolio_work-samples">
			
			<div class="portfolio_sample">
			
				<div class="portfolio_card-image">
					<img src="images/hover5.png" alt="image1">
				</div>
				
				<div class="portfolio_card-text">
					<p> HOVER.CSS </p>
				</div>
				
				<div class="portfolio_large-button">
					<a href="advance css hover effects/hover.html" target="_blank">View Project</a>
				</div>

			</div>
			
			
			<div class="portfolio_sample">
				
				<div class="portfolio_card-image">
					<img src="images/animation2.png" alt="image22">
				</div>
				
				<div class="portfolio_card-text">
					<p> CSS ANIMATIONS </p>
				</div>
				
				<div class="portfolio_large-button">
					<a href="advance css animations/animation1.html" target="_blank">View Project</a>
				</div>
				
			</div>
			
			
			<div class="portfolio_sample">
	
				<div class="portfolio_card-image">
					<img src="images/todo2.png" alt="image3">
				</div>
				
				<div class="portfolio_card-text">
					<p> PURE JAVASCRIPT </p>
				</div>

				<div class="portfolio_large-button">
					<a href="Javascript Todo List Project/TodoList.html" target="_blank">View Project</a>
				</div>

			</div>
			
		</div>
		

	<div class="portfolio_work-samples">
			
			<div class="portfolio_sample">
				
				<div class="portfolio_card-image">
					<img src="images/login_system.png" alt="image4">
				</div>
				
				<div class="portfolio_card-text">
					<p> PHP and MYSQL </p>
				</div>

				<div class="portfolio_large-button">
					<a href="complete registration system (latestly programmed)/register.php" target="_blank">View Project</a>
				</div>
			</div>
			
			
			<div class="portfolio_sample">
				
				<div class="portfolio_card-image">
					<img src="images/design_template.png" alt="image5">
				</div>
				
				<div class="portfolio_card-text">
					<p> HTML and CSS </p>
				</div>

				<div class="portfolio_large-button">
					<a href="template1.html" target="_blank">View Project</a>
				</div>
			</div>
			
			
			<div class="portfolio_sample">
				
				<div class="portfolio_card-image">
					<img src="images/ajax.png" alt="image6">
				</div>
				
				<div class="portfolio_card-text">
					<p> AJAX </p>
				</div>

				<div class="portfolio_large-button">
					<a href="AJAX/ajaxprogram5.php" target="_blank">View Project</a>
				</div>
			</div>
			
			
		</div>
		
	
</div>