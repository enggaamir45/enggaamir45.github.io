
<?php

$conn= mysqli_connect('localhost', 'root', '', 'user_data') or die('connection error');

?>