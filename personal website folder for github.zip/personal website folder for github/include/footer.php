<div class="footer">
	<div class="footer_profile-text">
		<p>Follow me to see my latest design and development projects and stay in touch to discuss for any freelance projects.  </p>
	</div>

		<div class="social-icons2">
			<div class="icons-container2">
			<a href="https://www.facebook.com/muhandis.aamir" target="_blank" class="fa fa-facebook"></a>
			</div>

			<div class="icons-container2">
			<a href="https://github.com/enggaamir45" target="_blank" class="fa fa-github"></a>
			</div>

			<div class="icons-container2">
			<a href="https://www.instagram.com/ar.ansari45/" target="_blank" class="fa fa-instagram"></a>
			</div>

			<div class="icons-container2">
			<a href="https://www.linkedin.com/in/aamir-ansari-a1aa608a/" target="_blank" class="fa fa-linkedin"></a>
			</div>	
		</div>
	
	<div class="back-to-top">	
	<button id="back-to-top-button" onClick="backToTop()">&#10094;</button>
	</div>

	<div class="useful-links">
		<div class="link1"><a href="home.php">Home</a></div>
		<div class="separator">::</div>
		<div class="link1"><a href="About.php">About</a></div>
		<div class="separator">::</div>
		<div class="link1"><a href="Portfolio.php">Portfolio</a></div>
		<div class="separator">::</div>
		<div class="link1"><a href="Resume.php">Resume</a></div>
		<div class="separator">::</div>
		<div class="link1"><a href="Contact.php">Contact</a></div>
	</div>
	
	<div class="copyright">
	<span>&copy; 2017 Aamir Husain Ansari. All rights reserved.</span>
	</div>		
</div>