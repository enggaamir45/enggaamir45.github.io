<?php

$db= mysqli_connect('localhost', 'root', '', 'personal_website') or die('connection error');

?>