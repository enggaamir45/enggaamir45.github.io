<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>AJAX 3</title>
</head>

<body>

<h1>JSON and AJAX</h1>

<button id="btn">Click me!</button>

<div id="animals"></div>

<script type="text/javascript" src="ajaxprogram3.js"></script>
</body>
</html>